//---------------------------------------------------------------------------
#ifndef SvcControllerH
#define SvcControllerH
//---------------------------------------------------------------------------
#include <SysUtils.hpp>
#include <Classes.hpp>
#include <SvcMgr.hpp>
#include <vcl.h>
#include "VaClasses.hpp"
#include "VaComm.hpp"
#include <ExtCtrls.hpp>

// OPC Automation ���
#include "OPCAutomation_TLB.h"

using namespace Opcautomation_tlb;

typedef IOPCAutoServerPtr _di_IOPCAutoServer;
typedef IOPCGroupsPtr     _di_IOPCGroups;
typedef IOPCGroupPtr      _di_IOPCGroup;

// (����: Items�� Item�� 'I'�� ���� �̸����� �����Ǿ����Ƿ� �̷��� �����մϴ�)
typedef OPCItemsPtr       _di_IOPCItems;
typedef OPCItemPtr        _di_IOPCItem;

//---------------------------------------------------------------------------
// �������� ���
#define PROTO_STX       0x02
#define PROTO_ETX       0x03
#define MAX_OPC_ITEMS   500

// OPC ������ ���� ����ü
struct TOPCItemInfo
{
    int         ItemID;
    String      TagName;
    String      DataType;
    String      Description;
    OPCItem*    pItem;          // _di_IOPCItem ��� OPCItem* ���
    VARIANT     varValue;
    VARIANT     varPrevValue;
    long        Quality;
    bool        Changed;
};

//---------------------------------------------------------------------------
class TGa1Agent : public TService
{
__published:    // IDE-managed Components
	TTimer *Timer1;
	TVaComm *MyComm;
	void __fastcall Timer1Timer(TObject *Sender);
    void __fastcall ServiceStart(TService *Sender, bool &Started);
    void __fastcall ServiceStop(TService *Sender, bool &Stopped);

    
private:        // User declarations
    // OPC ���� (����)
    _di_IOPCAutoServer OPCServer;
    _di_IOPCGroups     OPCGroups;
    _di_IOPCGroup      MyGroup;
    _di_IOPCItems      MyItems;
    
    // ������ �迭
    TOPCItemInfo    m_Items[MAX_OPC_ITEMS];
    int             m_ItemCount;
    
    // �ø��� ��� ����
    bool            m_bCommOpened;
    BYTE            m_SendBuffer[1024];
    bool            m_bFirstSend;

    // �α�
    // �α�
    TCHAR gbuf[65535];

    // ���� �Լ� - ����
    void __fastcall LogMessage(String msg);
    String __fastcall VariantToString(const tagVARIANT &v);
    int __fastcall GetQualityCode(long quality);
    
    // ���� �Լ� - CSV �ε�
    bool __fastcall LoadItemConfig(String filename);
    
    // ���� �Լ� - �ø��� ���
    bool __fastcall InitSerialPort(int portNum, int baudRate);
    void __fastcall CloseSerialPort();
    BYTE __fastcall CalcChecksum(BYTE* data, int len);
    int __fastcall BuildPacket(BYTE* buffer);
    void __fastcall SendToESP32();
    
    // ���� �Լ� - �� ��
    bool __fastcall IsValueChanged(int index);
    bool __fastcall HasAnyChanges();
    long __fastcall VariantToLong(const VARIANT &v);

public:         // User declarations
	__fastcall TGa1Agent(TComponent* Owner);
	TServiceController __fastcall GetServiceController(void);

	friend void __stdcall ServiceController(unsigned CtrlCode);
};
//---------------------------------------------------------------------------
extern PACKAGE TGa1Agent *Ga1Agent;
//---------------------------------------------------------------------------
#endif
