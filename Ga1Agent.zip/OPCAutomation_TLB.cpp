// ************************************************************************ //
// WARNING                                                                    
// -------                                                                    
// The types declared in this file were generated from data read from a       
// Type Library. If this type library is explicitly or indirectly (via        
// another type library referring to this type library) re-imported, or the   
// 'Refresh' command of the Type Library Editor activated while editing the   
// Type Library, the contents of this file will be regenerated and all        
// manual modifications will be lost.                                         
// ************************************************************************ //

// C++ TLBWRTR : $Revision:   1.151.1.0.1.27  $
// File generated on 2026-01-17 ���� 5:25:57 from Type Library described below.

// ************************************************************************  //
// Type Lib: E:\GA1Agent\OpcDaAuto.dll (1)
// LIBID: {28E68F91-8D75-11D1-8DC3-3C302A000000}
// LCID: 0
// Helpfile: 
// HelpString: OPC DA Automation Wrapper 2.02
// DepndLst: 
//   (1) v2.0 stdole, (C:\WINDOWS\system32\stdole2.tlb)
// Errors:
//   Error creating palette bitmap of (TOPCGroups) : Server e:\GabbianiAgent\opcdaauto.dll contains no icons
//   Error creating palette bitmap of (TOPCGroup) : Server e:\GabbianiAgent\opcdaauto.dll contains no icons
//   Error creating palette bitmap of (TOPCActivator) : Server e:\GabbianiAgent\opcdaauto.dll contains no icons
//   Error creating palette bitmap of (TOPCServer) : Server e:\GabbianiAgent\opcdaauto.dll contains no icons
// ************************************************************************ //

#include <vcl.h>
#pragma hdrstop

#include "OPCAutomation_TLB.h"

#if !defined(__PRAGMA_PACKAGE_SMART_INIT)
#define      __PRAGMA_PACKAGE_SMART_INIT
#pragma package(smart_init)
#endif

namespace Opcautomation_tlb
{


// *********************************************************************//
// GUIDS declared in the TypeLibrary                                      
// *********************************************************************//
const GUID LIBID_OPCAutomation = {0x28E68F91, 0x8D75, 0x11D1,{ 0x8D, 0xC3, 0x3C,0x30, 0x2A, 0x00,0x00, 0x00} };
const GUID IID_IOPCAutoServer = {0x28E68F92, 0x8D75, 0x11D1,{ 0x8D, 0xC3, 0x3C,0x30, 0x2A, 0x00,0x00, 0x00} };
const GUID CLSID_OPCGroups = {0x28E68F9E, 0x8D75, 0x11D1,{ 0x8D, 0xC3, 0x3C,0x30, 0x2A, 0x00,0x00, 0x00} };
const GUID IID_IOPCGroups = {0x28E68F95, 0x8D75, 0x11D1,{ 0x8D, 0xC3, 0x3C,0x30, 0x2A, 0x00,0x00, 0x00} };
const GUID CLSID_OPCGroup = {0x28E68F9B, 0x8D75, 0x11D1,{ 0x8D, 0xC3, 0x3C,0x30, 0x2A, 0x00,0x00, 0x00} };
const GUID IID_IOPCGroup = {0x28E68F96, 0x8D75, 0x11D1,{ 0x8D, 0xC3, 0x3C,0x30, 0x2A, 0x00,0x00, 0x00} };
const GUID IID_OPCItems = {0x28E68F98, 0x8D75, 0x11D1,{ 0x8D, 0xC3, 0x3C,0x30, 0x2A, 0x00,0x00, 0x00} };
const GUID IID_OPCItem = {0x28E68F99, 0x8D75, 0x11D1,{ 0x8D, 0xC3, 0x3C,0x30, 0x2A, 0x00,0x00, 0x00} };
const GUID DIID_DIOPCGroupEvent = {0x28E68F97, 0x8D75, 0x11D1,{ 0x8D, 0xC3, 0x3C,0x30, 0x2A, 0x00,0x00, 0x00} };
const GUID DIID_DIOPCGroupsEvent = {0x28E68F9D, 0x8D75, 0x11D1,{ 0x8D, 0xC3, 0x3C,0x30, 0x2A, 0x00,0x00, 0x00} };
const GUID IID_OPCBrowser = {0x28E68F94, 0x8D75, 0x11D1,{ 0x8D, 0xC3, 0x3C,0x30, 0x2A, 0x00,0x00, 0x00} };
const GUID DIID_DIOPCServerEvent = {0x28E68F93, 0x8D75, 0x11D1,{ 0x8D, 0xC3, 0x3C,0x30, 0x2A, 0x00,0x00, 0x00} };
const GUID IID_IOPCActivator = {0x860A4800, 0x46A4, 0x478B,{ 0xA7, 0x76, 0x7F,0x3A, 0x01, 0x93,0x69, 0xE3} };
const GUID CLSID_OPCActivator = {0x860A4801, 0x46A4, 0x478B,{ 0xA7, 0x76, 0x7F,0x3A, 0x01, 0x93,0x69, 0xE3} };
const GUID CLSID_OPCServer = {0x28E68F9A, 0x8D75, 0x11D1,{ 0x8D, 0xC3, 0x3C,0x30, 0x2A, 0x00,0x00, 0x00} };

};     // namespace Opcautomation_tlb
